package org.exam.util;

import java.util.Scanner;

import org.exam.model.Registration;

public class UserIntearaction {

	Scanner scanner=new Scanner(System.in);
	
	public Registration getRegDetails() {
		// TODO Auto-generated method stub
		Registration reg=new Registration();
	
		System.out.println("enter the customer name");
	  
		
		reg.setCustomerName(scanner.next());
		
		System.out.println("enter the customer mobile no");
		
		reg.setCustomerName(scanner.next());
		
		
		System.out.println("enter the registration fee");
		
		reg.setRegistrationFee(scanner.nextDouble());
		
		
		System.out.println("enter the age");
		
		reg.setAge(scanner.nextInt());
		
		reg.setActualRegFeePaid(calculateactualfee(reg.getRegistrationFee(),reg.getAge()));
		
	return reg;	
	}

	private double calculateactualfee(double registrationFee,int age) {
		
	      if(age<15)
	      {
	    	  return registrationFee;
	      }
	      else if(age>18 && age<25)
	      {
	    	  return 1.1*registrationFee;
	      }
	      else if(age>=25 && age<=50)
	      {
	    	  return 1.2*registrationFee;
	      }
	      else
	      {
	    	  return 1.3*registrationFee;
	      }
		
	}

}
