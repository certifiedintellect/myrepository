package org.exam.boot;

import java.util.Scanner;

import org.exam.model.Registration;
import org.exam.services.CustomerServicesImpl;
import org.exam.services.ICustomerServices;
import org.exam.util.UserIntearaction;

public class BootClass {

	
	
	public static void main(String[] args)
	{
		Scanner scanner=new Scanner(System.in);	
		UserIntearaction userinteraction=new UserIntearaction();
		ICustomerServices customerServices = new CustomerServicesImpl();
		do
		{
			System.out.println("1.create an account");
			System.out.println("2.exit");
			int ch=scanner.nextInt();
		
			if(ch==1)
			{
				Registration registration=userinteraction.getRegDetails();
				customerServices.createAccount(registration);
				
			}
			else if(ch==2)
			{
				System.exit(0);;
			}
			
			
		}while(true);
		
		
		
		
		
		
		
	}
	
}
