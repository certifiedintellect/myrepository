package org.exam.services;

import org.exam.model.Registration;

public interface ICustomerServices {

	public boolean createAccount(Registration registration);


}
