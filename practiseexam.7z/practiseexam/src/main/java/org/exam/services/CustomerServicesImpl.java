package org.exam.services;

import org.exam.Dao.CustomerDaoImpl;
import org.exam.Dao.ICustomerDao;
import org.exam.model.Registration;

public class CustomerServicesImpl implements ICustomerServices {

	ICustomerDao customerDao = new CustomerDaoImpl();
	
	@Override
	public boolean createAccount(Registration registration) {
		// TODO Auto-generated method stub
              customerDao.createAccount(registration);
              return type;
	}

}
