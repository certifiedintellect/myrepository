package org.exam.Dao;

import org.exam.model.Registration;

public class CustomerDaoImpl implements ICustomerDao {

	@Override
	public void createAccount(Registration registration) {
		// TODO Auto-generated method stub
		
	}

}
