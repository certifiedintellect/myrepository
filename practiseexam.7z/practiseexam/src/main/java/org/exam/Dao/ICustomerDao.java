package org.exam.Dao;

import org.exam.model.Registration;

public interface ICustomerDao {

	public void createAccount(Registration registration);

}
